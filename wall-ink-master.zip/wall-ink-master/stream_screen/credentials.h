#define ADMIN_PASSWORD "password123"  //this is the wifi password required to connect to the device when it's in admin mode
#define DEFAULT_IMAGE_KEY "hunter2" //if you change this here, you'll also want to change it in compressImage.cpp on the server
#define SSID0 "TestSSID0"
#define PASSWORD0 "batman123"
#define SSID1 "TestSSID1"
#define PASSWORD1 "123456"
